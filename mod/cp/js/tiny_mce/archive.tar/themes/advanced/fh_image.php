<?php
include '../../../../../../bin/core.php';


$file_name=handleUploadedFile('file');

function handleUploadedFile($_file,$_newname='')
{
	if(!isset($_FILES[$_file]))return 0;
	if($_FILES[$_file]['size']==0)return 0;
	if($_newname=='')$_newname=uniqid('',true);

$dir=$_newname[4];
if(!is_dir(FILE_DIR.$dir))mkdir(FILE_DIR.$dir);

if(!move_uploaded_file($_FILES[$_file]['tmp_name'], FILE_DIR.$dir.'/'.$_newname))
return 0;

return $dir.'/'.$_newname;
}

header("Location: image.htm?src=".FILE_URL.$file_name);
?>
